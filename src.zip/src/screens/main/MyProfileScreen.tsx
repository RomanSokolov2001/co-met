import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '../../hooks/useTheme';
import { loadStatusBar } from '../../utils/utilFunctions';
import ProfileButton from '../../components/ProfileButton';
import ProfileInfoSection from '../../components/ProfileInfoSection';
import ProfileContactSection from '../../components/ProfileContactSection';
import { logoutUser } from '../../services/AuthService';

const theme = useTheme();

export default function MyProfileScreen() {
  const [selectedSection, setSelectedSection] = useState('Info');
  const navigation = useNavigation();

  useFocusEffect(() => {
    loadStatusBar(theme.beige);
  });

  const handleLogout = async () => {
    try {
      const result = await logoutUser();
      if (result.success) {
        navigation.reset({
          index: 0,
          routes: [{ name: 'Login' }],
        });
      } else {
        Alert.alert('Logout Failed', result.error);
      }
    } catch (error) {
      Alert.alert('Error', 'An error occurred while logging out');
    }
  };

  function threeButtons() {
    const labels = ['Info', 'Posts', 'Contact'];
    return labels.map(label => (
      <ProfileButton 
        key={label}
        onPress={() => setSelectedSection(label)} 
        selectedSection={selectedSection} 
        label={label}
      >
        <Text>{label}</Text>
      </ProfileButton>
    ));
  }

  function getSectionView() {
    switch (selectedSection) {
      case 'Info':
        return <ProfileInfoSection />;
      case 'Posts':
        return <View />;
      case 'Contact':
        return <ProfileContactSection />;
      default:
        return null;
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.profileHeader}>
        <View style={styles.round}>
          <Image style={styles.avatar} />
        </View>
        <View style={styles.profileHeaderInfoField}>
          <Text style={styles.profileHeaderInfoTitle}>
            Name Surname, 21
          </Text>
          <Text style={styles.profileHeaderInfoText}>
            Estonia, Tallinn
          </Text>
          <Text style={styles.profileHeaderInfoText}>
            Study & Work
          </Text>
        </View>
      </View>
      <View style={styles.buttonContainer}>
        {threeButtons()}
      </View>
      {getSectionView()}
    </SafeAreaView>
  );
}

const roundSize = 120;

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: '#EDE0D4',
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    padding: 10,
  },
  logoutButton: {
    backgroundColor: theme.coal,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  logoutText: {
    color: 'white',
    fontFamily: 'Raleway-Medium',
    fontSize: 14,
  },
  profileHeader: {
    flexDirection: 'row',
    padding: 20,
  },
  avatar: {
    borderRadius: roundSize - 2,
    borderWidth: 2,
    borderColor: theme.coal,
  },
  round: {
    width: roundSize,
    height: roundSize,
    backgroundColor: theme.caramel,
    borderRadius: 100,
    borderWidth: 2,
    borderColor: theme.coal,
    alignItems: 'center',
  },
  profileHeaderInfoField: {
    padding: 20,
  },
  profileHeaderInfoTitle: {
    fontFamily: 'KiwiMaru-Medium',
    color: 'black',
    fontSize: 15,
    paddingBottom: 5,
  },
  profileHeaderInfoText: {
    fontFamily: 'Raleway-Medium',
    fontSize: 13,
    paddingBottom: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
});